from simpletransformers.ner.ner_model import NERModel
